## 项目说明

### 本项目的开发环境
开发语言：`C++`

本项目采用 `QT6 Community` 进行开发，集成开发环境为其配套的 `QT Creator`

下载地址：`https://www.qt.io/zh-cn/product/qt6`

本组亦 build 出了可执行文件，在本文件的同目录下有一名为 `build.rar` 的压缩包，解压后可运行（x64，windows 操作系统）