#ifndef CORE_H
#define CORE_H

#endif // CORE_H
